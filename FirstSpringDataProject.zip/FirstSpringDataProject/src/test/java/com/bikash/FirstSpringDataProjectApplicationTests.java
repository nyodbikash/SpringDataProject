package com.bikash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringDataProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
