package com.bikash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringDataProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSpringDataProjectApplication.class, args);
	}

}
